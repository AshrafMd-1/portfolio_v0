# a) Intensity Transformations
import cv2
fname=input("Enter the path of the image to display: ")
img_arr=cv2.imread(fname)
cv2.imshow("Displaying Image",img_arr)
cv2.waitKey(0)
cv2.destroyAllWindows()

# b) Gray scale image
import cv2
fname=input("Enter the path of the image to display: ")
img_arr=cv2.imread(fname)
grayscale_img_arr=cv2.cvtColor(img_arr,cv2.COLOR_BGR2GRAY)
cv2.imshow("GrayScale Image",grayscale_img_arr)
cv2.waitKey(0)
cv2.destroyAllWindows()

# c) Display the size of the image
import cv2
fname=input("Enter the path of the image to display: ")
img_arr=cv2.imread(fname)
height,width,channel=img_arr.shape
print(f"Size of the image : {height}x{width}x{channel}")
