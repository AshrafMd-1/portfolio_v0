# a) Loading and displaying characteristics of an audio fileLoading and displaying characteristics of an audio file
import librosa

fpath = input("Enter path of the audio file: ")
samples, sampling_rate = librosa.load(fpath, sr=None, mono=False)

print("Sampling rate:", sampling_rate)
print("Number of samples:", samples.shape[-1])
n_channels = samples.shape[-2] if len(samples.shape) != 1 else 1
print("Number of channels:", n_channels)
duration = samples.shape[-1] / sampling_rate
print("Duration:", duration, "s")

# b) Spectral representations
import librosa
from librosa import display
import matplotlib.pyplot as plt
import numpy as np

fpath = input("Enter path of the audio file: ")
samples, sampling_rate = librosa.load(fpath, sr=None, mono=True)

signal_stft = librosa.stft(samples)
signal_db = librosa.amplitude_to_db(np.abs(signal_stft), ref=np.max)

fig, ax = plt.subplots()
img = display.specshow(signal_db, x_axis="time", y_axis="linear", ax=ax)
ax.set(title="Spectrogram of {}".format(fpath))
fig.colorbar(img, ax=ax, format="%+2.0f dB")
plt.show()

# c) Feature extraction and manipulation
import librosa
from librosa import display
import matplotlib.pyplot as plt
import numpy as np

fpath = input("Enter path of the audio file: ")
samples, sampling_rate = librosa.load(fpath, sr=None, mono=True, duration=2.0)

signal_stft = librosa.stft(samples)
signal_db = librosa.amplitude_to_db(np.abs(signal_stft), ref=np.max)

spec_cent = librosa.feature.spectral_centroid(y=samples, sr=sampling_rate)
spec_cent_times_like = librosa.times_like(spec_cent, sr=sampling_rate)

spec_contrast = librosa.feature.spectral_contrast(S=np.abs(signal_stft), sr=sampling_rate)

spec_flatness = librosa.feature.spectral_flatness(y=samples)
spec_flatness_times_like = librosa.times_like(spec_flatness, sr=sampling_rate)

spec_rolloff = librosa.feature.spectral_rolloff(y=samples, sr=sampling_rate, roll_percent=0.85)
spec_rolloff_times_like = librosa.times_like(spec_rolloff, sr=sampling_rate)

spec_bw = librosa.feature.spectral_bandwidth(y=samples, sr=sampling_rate, p=2)
spec_bw_times_like = librosa.times_like(spec_bw, sr=sampling_rate)

mel_spec = librosa.feature.melspectrogram(y=samples, sr=sampling_rate)

rms_frames = librosa.feature.rms(y=samples)
rms_frames_times_like = librosa.times_like(rms_frames, sr=sampling_rate)

fig, ax = plt.subplots(nrows=2, ncols=2)
normal_spec_img = librosa.display.specshow(signal_db, x_axis="time", y_axis="linear", ax=ax[1, 1])
fig.colorbar(normal_spec_img, ax=[ax[1, 1]], format="%+2.0f dB")
ax[1, 1].set(title="Audio Spectrogram")

ax[0, 1].plot(spec_cent_times_like, spec_cent.T, label="Spectral Centroid")
spec_cont_img = librosa.display.specshow(spec_contrast, x_axis='time', ax=ax[0, 0])
fig.colorbar(spec_cont_img, ax=[ax[0, 0]])
ax[0, 0].set(ylabel='Frequency bands', title='Spectral Contrast')

ax[0, 1].plot(spec_flatness_times_like, spec_flatness.T, label="Spectral Flatness")
ax[0, 1].plot(spec_rolloff_times_like, spec_rolloff.T, label="Spectral Rolloff (85%)")
ax[0, 1].plot(spec_bw_times_like, spec_bw.T, label="Spectral Bandwidth (Order - 2)")

mel_spec_img = librosa.display.specshow(mel_spec, x_axis="time", y_axis="log", ax=ax[1, 0])
fig.colorbar(mel_spec_img, ax=[ax[1, 0]])
ax[1, 0].set(title="Mel Spectrogram")

ax[0, 1].semilogy(rms_frames_times_like, rms_frames[0], label="RMS Energy")
ax[0, 1].legend(loc='lower right')
ax[0, 1].set(xlabel="Time", title="Other Features")

plt.show()

# d) Visualize audio
import librosa
from librosa import display
import matplotlib.pyplot as plt

fpath = input("Enter path of the audio file: ")
samples_mono, sr_mono = librosa.load(fpath, sr=None, mono=True)
samples_multi, sr_multi = librosa.load(fpath, sr=None, mono=False)

plt.subplot(2, 1, 1)
librosa.display.waveshow(y=samples_mono, sr=sr_mono)
plt.title("Mono")

plt.subplot(2, 1, 2)
librosa.display.waveshow(y=samples_multi, sr=sr_multi)
plt.title("Multi (here stereo)")

plt.show()

