# a) Plot a Histogram of an image
import cv2
import matplotlib.pyplot as plt

fname = input("Enter the path of the image - 1: ")
img_arr = cv2.imread(fname)
hist_data = cv2.calcHist([img_arr], [0], None, [256], [0, 256])
plt.plot(hist_data)
plt.show()
cv2.waitKey(0)
cv2.destroyAllWindows()

# b) Use Histogram equalization for contrast adjustment. Display the original image and the Histogram equalization by stacking side by side
import cv2
import numpy as np

fname = input("Enter the path of the image - 1: ")
img_arr = cv2.imread(fname, 0)

equalized_img = cv2.equalizeHist(img_arr)

stack = np.hstack((img_arr, equalized_img))
cv2.imshow("Original | Histogram Equalization", stack)
cv2.waitKey(0)
cv2.destroyAllWindows()

