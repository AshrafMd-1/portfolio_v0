# a) Use the following smoothing spatial filters for reduction of blur and noise in the image.

# 1. Linear Filter (Mean Filter)
import cv2
import numpy as np

fname = input("Enter the path of the image: ")
img_arr = cv2.imread(fname, 0)
img_arr = np.array(img_arr, dtype=np.uint8)
cv2.imshow("Noisy Image", img_arr)

for kernel_size in range(3, 30, 3):
    blurred_noisy_img = cv2.blur(img_arr, (kernel_size, kernel_size))

blurred_noisy_img = np.array(blurred_noisy_img, dtype=np.uint8)
cv2.imshow("Kenel size: {}".format(kernel_size), blurred_noisy_img)
cv2.waitKey(0)
cv2.destroyAllWindows()

# 2. Order Statistics (Non-linear) filter
import cv2
import numpy as np

fname = input("Enter the path of the image: ")
img_arr = cv2.imread(fname, 0)
cv2.imshow("Noisy Image", img_arr)

for kernel_size in range(3, 30, 3):
    if kernel_size:
        median_blur_noisy_img = cv2.medianBlur(img_arr, kernel_size)
        cv2.imshow("Kernel Size: {}".format(kernel_size), median_blur_noisy_img)
        cv2.waitKey(0)

cv2.destroyAllWindows()