# a) Demonstrate various intensity transformations operations on Images such as

# 1. Image Negatives (Linear)
import cv2
import numpy as np

fname = input("Enter the path of the image - 1: ")
img_arr = cv2.imread(fname)
dim1, dim2, channels = img_arr.shape
negative_img_arr = 255 - img_arr
stack = np.hstack((img_arr, negative_img_arr))
cv2.imshow("Image | Image Negative", stack)
cv2.waitKey(0)
cv2.destroyAllWindows()

# 2. Log Transformations
import cv2
import numpy as np

fname = input("Enter the path of the image - 1: ")
img_arr = cv2.imread(fname)
dim1, dim2, channels = img_arr.shape

scaling_constant = 255 / np.log(1 + np.max(img_arr))
log_img_arr = scaling_constant * np.log(img_arr + 1)
log_img_arr = np.array(log_img_arr, dtype=np.uint8)
stack = np.hstack((img_arr, log_img_arr))

cv2.imshow("Image | Log Image", stack)
cv2.waitKey(0)
cv2.destroyAllWindows()

# 3. Power-Law (Gamma) Transformations
import cv2
import numpy as np

fname = input("Enter the path of the image: ")
img_arr = cv2.imread(fname)
dim1, dim2, channels = img_arr.shape

for gamma in (0.1, 0.4, 0.5, 1.0, 1.2, 2.0):
    gamma_img = np.array(255 * (img_arr / 255) ** gamma, dtype=np.uint8)
cv2.imshow("Gamma: {}".format(gamma), gamma_img)
cv2.waitKey(0)
cv2.destroyAllWindows()

# b) Apply Piece-wise Linear Transformation for enhancing contrast of an image
import cv2
import numpy as np

fname = input("Enter the path of the image: ")
img_arr = cv2.imread(fname, 0)  #grayscale


def contrast_stretch(pix, r1, s1, r2, s2):
    if (0 <= pix and pix <= r1):
        return (s1 / r1) * pix
    elif (r1 < pix and pix <= r2):
        return ((s2 - s1) / (r2 - r1)) * (pix - r1) + s1
    else:
        return ((255 - s2) / (255 - r2)) * (pix - r2) + s2


contrast_stretch = np.vectorize(contrast_stretch)

r1, s1, r2, s2 = 70, 0, 140, 255
contrast_stretched_img = contrast_stretch(img_arr, r1, s1, r2, s2)
stack = np.hstack((img_arr, contrast_stretched_img))
cv2.imshow("Image | Contrast Strectched", stack)
cv2.waitKey(0)
cv2.destroyAllWindows()